import { BasePage } from './base';

export class SettingsUsagePage extends BasePage {
	url = '/settings/usage';

	getters = {};

	actions = {};
}
