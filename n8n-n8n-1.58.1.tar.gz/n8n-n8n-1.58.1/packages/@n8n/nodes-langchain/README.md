![Banner image](https://user-images.githubusercontent.com/10284570/173569848-c624317f-42b1-45a6-ab09-f0ea3c247648.png)

# n8n-nodes-langchain

This repo contains nodes to use n8n in combination with [LangChain](https://langchain.com/).

These nodes are still in Beta state and are only compatible with the Docker image `docker.n8n.io/n8nio/n8n:ai-beta`.

## License

You can find the license information [here](https://github.com/n8n-io/n8n/blob/master/README.md#license)
