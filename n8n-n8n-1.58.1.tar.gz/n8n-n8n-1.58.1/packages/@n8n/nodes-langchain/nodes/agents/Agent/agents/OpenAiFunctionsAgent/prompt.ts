export const SYSTEM_MESSAGE = 'You are a helpful AI assistant.';
