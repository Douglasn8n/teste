import { sharedConfig } from '@n8n/storybook/main';

const config = { ...sharedConfig };
export default config;
