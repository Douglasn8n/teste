import { createEventBus } from '@n8n/chat/utils';

export const chatEventBus = createEventBus();
